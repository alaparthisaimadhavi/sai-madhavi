package sai.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import sai.model.Customer;


public interface CustomerRepository extends JpaRepository<Customer, Integer>{

}
