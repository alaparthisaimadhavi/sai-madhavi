package sai.util;

import org.springframework.stereotype.Component;

import sai.model.Customer;



@Component
public class CustomerUtil {
	public void mapToActualObject(Customer actual, Customer customer) {
		if(customer.getFirstname()!=null)
		actual.setFirstname(customer.getFirstname());
		actual.setLastname(customer.getLastname());
		actual.setAddress(customer.getAddress());
		actual.setCity(customer.getCity());
		if(customer.getState()!=null)
			actual.setState(customer.getState());
		actual.setOrdertotal(customer.getOrdertotal());
		
	}
}
