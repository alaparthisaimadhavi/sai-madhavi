package sai.service;

import java.util.List;
import java.util.Optional;
import sai.model.Customer;

public interface ICustomerService {
	Integer saveCustomer(Customer a);
	void updateCustomer(Customer a);
	
	void deleteCustomer(Integer a);

	Optional<Customer> getOneCustomer(Integer id);
	List<Customer> getAllCustomers();

	boolean isCustomerExist(Integer id);
}
