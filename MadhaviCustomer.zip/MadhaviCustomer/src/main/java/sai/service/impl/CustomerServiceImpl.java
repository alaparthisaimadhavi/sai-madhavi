package sai.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import sai.model.Customer;
import sai.repo.CustomerRepository;
import sai.service.ICustomerService;




@Service
public class CustomerServiceImpl  implements ICustomerService{
	@Autowired
	private CustomerRepository repo;
	
	@Override
	public Integer saveCustomer(Customer a) {
		a = repo.save(a);
		return a.getId();
	}

	@Override
	public void updateCustomer(Customer a) {
		repo.save(a);
	}

	@Override
	public void deleteCustomer(Integer id) {
		repo.deleteById(id);
	}

	@Override
	public Optional<Customer> getOneCustomer(Integer id) {
		return repo.findById(id);
	}

	@Override
	public List<Customer> getAllCustomers() {
		return repo.findAll();
	}

	@Override
	public boolean isCustomerExist(Integer id) {
		return repo.existsById(id);
	}

}


